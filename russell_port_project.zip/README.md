# Port de Plaisance Russell

## Installation
1. Clone le repo
2. Crée un fichier `.env` à partir de `.env.example`
3. Lance `npm install`
4. Démarre avec `node server.js`

## Déploiement sur Render
- Push sur GitHub
- Connecte ton repo sur https://render.com
- Configure MONGO_URI et JWT_SECRET
